# Chroma42

> Инженерный генератор цветовых токенов с проверяемой методологией доступности.

Chroma42 генерирует и проверяет цветовые пары по измеримым критериям
WCAG 2.2 (SC 1.4.3, 1.4.6, 1.4.11, 2.4.13). Отчёт показывает проверенные
пары, коэффициенты и статусы, но **не заменяет полный аудит доступности
продукта**.

## Документация

| Документ | Содержание |
|---|---|
| [`Docs/Chroma42 Color Pair Methodology.md`](Docs/Chroma42%20Color%20Pair%20Methodology.md) | Нормативная база: стандарты, пороги, пары, политики, паспорт |
| [`Docs/Общая архитектура Chroma42.md`](Docs/Общая%20архитектура%20Chroma42.md) | Устройство движков и модель данных |
| [`Docs/roadmap/`](Docs/roadmap/Роадмап%20с%20учётом%20всех%20запланированных%20фич.md) | План развития с оценками и приоритетами |

## Архитектура

Семь изолированных модулей. Они не импортируют друг друга напрямую
и общаются через строгие TypeScript-интерфейсы.

| Модуль | Путь | Ответственность |
|---|---|---|
| Color | `src/engine/color` | HEX ↔ sRGB ↔ OKLab ↔ OKLCH, вписывание в gamut |
| Scale | `src/engine/scale` | Генерация тональных рядов 0–100 |
| Contrast | `src/engine/contrast` | WCAG 2.2, APCA, альфа-композитинг |
| Policy | `src/engine/policy` | Реестр пар (30 пар), политики, пороги по режимам |
| Solver | `src/engine/solver` | Подбор тонов, проходящих порог |
| Audit | `src/engine/audit` | Проверка, паспорт, Markdown-отчёт |
| Seeds | `src/engine/seeds` | Якорные сиды статусов и гармонические схемы |

Полное описание — в [архитектуре](Docs/Общая%20архитектура%20Chroma42.md).

### Почему OKLCH, а не HSL

HSL некорректно воспринимается человеком: 50% lightness у жёлтого и у синего
выглядят совершенно разными. OKLCH перцептивно равномерен, поэтому шкала
получается предсказуемой без ручной подгонки.

Цвета вне gamut sRGB (яркие синий и жёлтый) вписываются **бисекцией по
хроматичности** при неизменных светлоте и оттёнке — так воспринимаемый цвет
не «плывёт», в отличие от наивного обрезания каналов.

### Сиды вместо литеральных цветов

Статусные цвета не задаются вручную: якорные сиды (`STATUS_SEED_ANCHORS`)
— единственный источник истины, а гармонические схемы порождают полный
набор сидов (primary / secondary / tertiary / neutral) с сохранением
воспринимаемого контраста. Хрома вписывается в gamut sRGB бисекцией
с запасом `chromaSafety`, поэтому жёлтые и синие сиды не «выцветают».

Доступные схемы: монохром, аналоговая, комплементарная,
сплит-комплементарная, триада, тетрада (`HARMONY_SCHEMES`).

### Проверяем пары, а не цвета

Цвет сам по себе не бывает доступным или недоступным — бывает доступной
**пара** в конкретном контексте. Реестр `PAIR_REGISTRY` описывает пары шести
категорий: `text`, `container`, `status`, `form`, `focus`, `glass`.

### Прозрачность проверяется только после композитинга

WCAG не умеет работать с альфой. Движок «запекает» прозрачный токен на
обязательной подложке и лишь затем считает контраст. Стеклянный токен без
указанной подложки получает статус `requires-manual-review`.

## Использование

```ts
import {
    generateScale,
    generateNeutralScale,
    generateHarmonySeeds,
    STATUS_SEED_ANCHORS,
    getPolicy,
    REQUIRED_PAIRS,
    buildAuditReport,
    buildPassport,
    buildThemeBundle,
} from './src/engine';

// Статусы автоматически берутся из STATUS_SEED_ANCHORS,
// опции chromaSafety/chromaFactors переопределяют поведение схемы.
const seeds = generateHarmonySeeds('#00543b', 'analogous');

// Полный пайплайн для UI: шкалы → раскладка 8 режимов → аудит → тема.
const { theme } = buildThemeBundle('Моя тема', seeds, 'gov-aa');
console.log(theme.audit.summary); // { passed, failed, exportAllowed }

const primary = generateScale(seeds.primary);
const neutral = generateNeutralScale(seeds.primary);

const tokens = {
    surface: neutral[99],
    'on-surface': neutral[5],
    primary: primary[50],
    'on-primary': neutral[99],
    // ... остальные токены режима
};

const report = buildAuditReport(
    REQUIRED_PAIRS,
    { 'light-normal': tokens },
    getPolicy('gov-aa'),
);

console.log(report.summary); // { passed, failed, exportAllowed }
console.log(buildPassport(report, 'gov-aa', new Date().toISOString()));
```

## Политики

| Политика | Уровень | Строгость |
|---|---|---|
| `standard-aa` | WCAG 2.2 AA | мягкая |
| `standard-aaa` | WCAG 2.2 AAA | строгая |
| `gov-aa` | AA (ГОСТ Р 52872-2019 — reference, via WCAG) | строгая |
| `gov-aaa` | AAA + ссылочные стандарты | строгая |
| `gov-high-contrast` | текст 7:1, фокус 4.5:1 | строгая |
| `reduced-transparency` | AA + отключение прозрачности | строгая |

В строгих политиках экспорт блокируется при провале обязательных пар
(`exportAllowed: false`).

## Команды

```bash
npm install
npm test          # 129 тестов
npm run typecheck # tsc --noEmit
npm run dev       # аудит-панель (Next.js) на localhost:3000
npm run gen:theme # регенерация app/theme-*.css при смене реестра пар
npm run build:lib # сборка библиотеки в dist/ (ESM + .d.ts)
npm pack          # tarball для локального потребления (file:vendor/*.tgz)
```

## Использование как библиотека

Пакет экспортирует движок **без React и без Next.js** — пригоден для
серверного рендера, воркеров и генерации CSS. Точка входа `chroma42`
(движки + модель темы + пайплайн сборки).

```ts
import {
    buildThemeBundle,
    defaultSeeds,
    flattenModes,
    generateScale,
    getPolicy,
} from 'chroma42';

// Тема из сида + политики доступности
const { theme } = buildThemeBundle('Моя тема', defaultSeeds(), 'standard-aa');

// Плоская карта токенов по режимам (HEX-значения, пары разрешены)
const flat = flattenModes(theme);
const light = flat['light-normal']; // { primary: '#…', surface: '#…', … }

// Отчёт доступности
console.log(theme.audit.summary);
// { totalPairsChecked: 184, passed: 184, warnings: 0, failed: 0, exportAllowed: true }
```

Режимы: `light-normal`, `light-medium`, `light-high`,
`light-reduced-transparency` и те же четыре для `dark`.

**Публикация.** Workflow `.github/workflows/publish.yml` публикует пакет
в npm по релизу; нужен секрет `NPM_TOKEN`. До публикации пакет
потребляется как tarball: `npm pack` в этом репозитории → положить
`.tgz` в `vendor/` потребителя и указать зависимость
`"chroma42": "file:./vendor/chroma42-<версия>.tgz"`.

### Аудит-панель (этап 9)

Минималистичный интерфейс: выбор primary-сида и гармонии, переключение
8 режимов, таблица проверок с расшифровкой «почему», скачивание
отчётов (JSON/MD) и экспорт темы. Движок работает целиком на клиенте —
изображения и темы никуда не отправляются.

## Документация

- `Docs/Chroma42 Color Pair Methodology.md` — методология и нормативная база
- `Docs/Общая архитектура Chroma42.md` — архитектура движков
- `Docs/roadmap/Роадмап с учётом всех запланированных фич.md` — план развития

## Юридический дисклеймер

Chroma42 обеспечивает математическую валидацию цветовых контрастов и генерацию
фолбэков в соответствии с методологиями WCAG 2.2 и ссылочными требованиями
EN 301 549 / ГОСТ Р 52872-2019. Итоговое соответствие цифрового продукта
стандартам доступности зависит также от семантики HTML, клавиатурной навигации,
ARIA-атрибутов и поведения компонентов, что находится вне зоны ответственности
генератора токенов. Данный отчёт не является юридическим сертификатом
доступности.

